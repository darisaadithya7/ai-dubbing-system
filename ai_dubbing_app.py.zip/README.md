# 🎬 AI Dubbing System

[![Streamlit App](https://static.streamlit.io/badges/streamlit_badge_black_white.svg)](https://your-app-url.streamlit.app)

An end-to-end AI pipeline that automatically dubs any English video into multiple languages using state-of-the-art open-source models — completely free, no paid APIs.

![Python](https://img.shields.io/badge/Python-3.10-blue)
![Whisper](https://img.shields.io/badge/Whisper-OpenAI-green)
![HuggingFace](https://img.shields.io/badge/HuggingFace-Helsinki--NLP-yellow)
![Coqui TTS](https://img.shields.io/badge/TTS-Coqui_XTTS_v2-orange)
![Streamlit](https://img.shields.io/badge/UI-Streamlit-red)

---

## 🚀 Live Demo
👉 [Click here to try it live](https://your-app-url.streamlit.app)

---

## 🧠 How It Works

```
English Video
      │
      ▼
┌─────────────────┐
│  Stage 1        │  OpenAI Whisper
│  Transcription  │  Speech → Timestamped Text
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Stage 2        │  Helsinki-NLP (HuggingFace)
│  Translation    │  English → Target Language
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Stage 3        │  Coqui XTTS v2
│  Voice Synthesis│  Text → Audio + Timing Correction
└────────┬────────┘
         │
         ▼
┌─────────────────┐
│  Stage 4        │  MoviePy
│  Video Merge    │  Replace original audio
└────────┬────────┘
         │
         ▼
   Dubbed Video ✅
```

---

## ⚙️ Tech Stack

| Component | Technology | Purpose |
|---|---|---|
| Transcription | OpenAI Whisper (local) | Speech to text with timestamps |
| Translation | Helsinki-NLP via HuggingFace | 1000+ language pair models |
| Text to Speech | Coqui XTTS v2 | Multilingual neural voice synthesis |
| Audio Processing | Librosa | Timing correction via time-stretching |
| Video Editing | MoviePy | Audio replacement and export |
| UI | Streamlit | Clean web interface |

---

## 🔑 Key Technical Feature — Audio Timing Correction

Dubbed speech takes different amounts of time than the original. This project uses **dynamic audio time-stretching** via `librosa.effects.time_stretch()` to compress or expand each audio segment to exactly match the original timing — keeping the dubbed video perfectly in sync.

---

## 🏃 Run Locally

```bash
git clone https://github.com/darisaadithya7/ai-dubbing-system
cd ai-dubbing-system
pip install -r requirements.txt
streamlit run app.py
```

---

## 🌐 Supported Languages
Hindi · Telugu · French · Spanish · German

---

## 👨‍💻 Author
**Darisa Adithya**
- LinkedIn: [linkedin.com/in/darisa-adithya-708232275](https://linkedin.com/in/darisa-adithya-708232275)
- GitHub: [github.com/darisaadithya7](https://github.com/darisaadithya7)
