---
title: AI Dubbing System
emoji: 🎬
colorFrom: purple
colorTo: blue
sdk: gradio
sdk_version: 4.0.0
app_file: app.py
pinned: false
---

# 🎬 AI Dubbing System

Automatically dubs any English video into multiple languages using state-of-the-art AI models.

## How it works
1. **Whisper** transcribes speech to timestamped text
2. **Helsinki-NLP** translates to target language  
3. **Coqui XTTS v2** generates natural male dubbed voice
4. **MoviePy** replaces original audio in video

## Supported Languages
Hindi · Telugu · French · Spanish · German
