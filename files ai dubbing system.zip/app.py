import gradio as gr
import whisper
import librosa
import soundfile as sf
import numpy as np
from pydub import AudioSegment, effects
from moviepy.editor import VideoFileClip, AudioFileClip
from transformers import MarianMTModel, MarianTokenizer
from TTS.api import TTS
import os
import torch

# ── Language configs ─────────────────────────────────────────────
LANGUAGES = {
    'Hindi':   {'helsinki': 'hi', 'tts_lang': 'hi', 'tts_voice': 'male'},
    'Telugu':  {'helsinki': 'te', 'tts_lang': 'te', 'tts_voice': 'male'},
    'French':  {'helsinki': 'fr', 'tts_lang': 'fr', 'tts_voice': 'male'},
    'Spanish': {'helsinki': 'es', 'tts_lang': 'es', 'tts_voice': 'male'},
    'German':  {'helsinki': 'de', 'tts_lang': 'de', 'tts_voice': 'male'},
}

# ── Load models once at startup ──────────────────────────────────
print("Loading Whisper model...")
whisper_model = whisper.load_model("base")
print("✅ Whisper ready")

print("Loading Coqui TTS model...")
tts_model = TTS("tts_models/multilingual/multi-dataset/xtts_v2")
print("✅ TTS ready")

# ── Stage 1: Transcription ───────────────────────────────────────
def transcribe(video_path):
    print("Transcribing...")
    result = whisper_model.transcribe(video_path)
    segments = [
        {'start': round(s['start'], 2),
         'end':   round(s['end'],   2),
         'text':  s['text'].strip()}
        for s in result['segments']
    ]
    print(f"✅ {len(segments)} segments transcribed")
    return segments

# ── Stage 2: Translation ─────────────────────────────────────────
def translate(segments, target_language):
    lang_code  = LANGUAGES[target_language]['helsinki']
    model_name = f"Helsinki-NLP/opus-mt-en-{lang_code}"
    print(f"Loading translation model {model_name}...")
    tokenizer  = MarianTokenizer.from_pretrained(model_name)
    model      = MarianMTModel.from_pretrained(model_name)

    translated = []
    for seg in segments:
        inputs = tokenizer(seg['text'], return_tensors="pt", padding=True)
        out    = model.generate(**inputs)
        text   = tokenizer.decode(out[0], skip_special_tokens=True)
        translated.append({'start': seg['start'], 'end': seg['end'], 'text': text})
        print(f"  {seg['text']} → {text}")

    print("✅ Translation done")
    return translated

# ── Stage 3: TTS with male voice ────────────────────────────────
def synthesize(segments, target_language, output_dir="outputs"):
    os.makedirs(output_dir, exist_ok=True)
    lang_code   = LANGUAGES[target_language]['tts_lang']
    sample_rate = 22050
    total_dur   = segments[-1]['end']
    final_audio = np.zeros(int(total_dur * sample_rate))

    # Use a male speaker reference — XTTS v2 supports speaker embedding
    # We use a built-in male voice reference
    speaker = "Claribel Dervla" if lang_code == "en" else None

    for i, seg in enumerate(segments):
        wav_path = f"{output_dir}/seg_{i}.wav"
        try:
            tts_model.tts_to_file(
                text=seg['text'],
                language=lang_code,
                file_path=wav_path,
                speaker=speaker,
            )

            audio, sr = librosa.load(wav_path, sr=sample_rate)

            # Boost volume
            audio_seg = AudioSegment.from_wav(wav_path)
            audio_seg = audio_seg + 10
            audio_seg = effects.normalize(audio_seg)
            audio_seg.export(wav_path, format='wav')
            audio, sr = librosa.load(wav_path, sr=sample_rate)

            # Time stretch
            target_dur  = seg['end'] - seg['start']
            target_samp = int(target_dur * sample_rate)
            if target_samp <= 0:
                continue
            ratio = (len(audio) / sample_rate) / target_dur
            if ratio > 1.25 or ratio < 0.75:
                audio = librosa.effects.time_stretch(audio, rate=ratio)

            # Fit to slot
            if len(audio) > target_samp:
                audio = audio[:target_samp]
            else:
                audio = np.pad(audio, (0, target_samp - len(audio)))

            # Place at timestamp
            start_s = int(seg['start'] * sample_rate)
            end_s   = start_s + len(audio)
            if end_s > len(final_audio):
                audio = audio[:len(final_audio) - start_s]
                end_s = len(final_audio)
            final_audio[start_s:end_s] = audio
            print(f"  [{i+1}/{len(segments)}] {seg['start']}s → {seg['end']}s ✅")

        except Exception as e:
            print(f"  [{i+1}] Skipped: {e}")
        finally:
            if os.path.exists(wav_path):
                os.remove(wav_path)

    # Normalize
    max_val = np.max(np.abs(final_audio))
    if max_val > 0:
        final_audio = final_audio / max_val * 0.95
    np.clip(final_audio, -1.0, 1.0, out=final_audio)

    out_path = f"{output_dir}/dubbed_audio.wav"
    sf.write(out_path, final_audio, sample_rate)
    print(f"✅ Audio saved → {out_path}")
    return out_path

# ── Stage 4: Merge video ─────────────────────────────────────────
def merge(video_path, audio_path, output_dir="outputs"):
    out_path = f"{output_dir}/dubbed_video.mp4"
    video    = VideoFileClip(video_path)
    audio    = AudioFileClip(audio_path)
    if audio.duration > video.duration:
        audio = audio.subclip(0, video.duration)
    final = video.set_audio(audio)
    final.write_videofile(out_path, codec='libx264', audio_codec='aac',
                          verbose=False, logger=None)
    video.close(); audio.close()
    print(f"✅ Video saved → {out_path}")
    return out_path

# ── Full pipeline ────────────────────────────────────────────────
def dub_video(video_file, target_language, progress=gr.Progress()):
    try:
        progress(0.05, desc="Transcribing audio...")
        segments = transcribe(video_file)

        progress(0.30, desc="Translating text...")
        translated = translate(segments, target_language)

        progress(0.60, desc="Generating dubbed voice...")
        audio_path = synthesize(translated, target_language)

        progress(0.85, desc="Merging audio into video...")
        video_path = merge(video_file, audio_path)

        progress(1.0, desc="Done!")
        return video_path, "🎉 Dubbing complete! Download your video."

    except Exception as e:
        return None, f"❌ Error: {str(e)}"

# ── Gradio UI ────────────────────────────────────────────────────
with gr.Blocks(title="🎬 AI Dubbing System") as demo:
    gr.Markdown("""
    # 🎬 AI Dubbing System
    **Upload any English video → Select language → Get dubbed video with male voice**
    
    Built with: OpenAI Whisper · Helsinki-NLP · Coqui XTTS v2 · MoviePy
    """)

    with gr.Row():
        with gr.Column():
            video_in   = gr.Video(label="Upload English Video (MP4)")
            lang_drop  = gr.Dropdown(choices=list(LANGUAGES.keys()),
                                     value="Hindi", label="Target Language")
            submit_btn = gr.Button("🎙️ Start Dubbing", variant="primary", size="lg")
        with gr.Column():
            video_out  = gr.Video(label="Dubbed Video")
            status_out = gr.Textbox(label="Status", interactive=False)

    submit_btn.click(fn=dub_video,
                     inputs=[video_in, lang_drop],
                     outputs=[video_out, status_out])

    gr.Markdown("""
    | Stage | Model | What happens |
    |-------|-------|-------------|
    | 1 | OpenAI Whisper | Transcribes speech to timestamped text |
    | 2 | Helsinki-NLP | Translates to target language |
    | 3 | Coqui XTTS v2 | Generates natural male dubbed voice |
    | 4 | MoviePy | Replaces original audio in video |
    """)

demo.launch()
